/**
 * tag service
 */

import { factories } from '@strapi/strapi';





const service = factories.createCoreService('api::tag.tag', ({ strapi }) => ({

}));

export default service;