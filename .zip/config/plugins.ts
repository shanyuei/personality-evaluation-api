export default () => ({
    'generate-data': { enabled: true },
});
